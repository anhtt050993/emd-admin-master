<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Filament\Resources\ClientResource\Pages;
use App\Models\{
    Client,
    ClientAccess,
    SenderAccess,
    SenderTransport,
};
use Filament\Forms\Components;
use Filament\Resources\{
    Form,
    Resource,
    Table,
};
use Filament\Tables\Actions\{
    DeleteAction,
    DeleteBulkAction,
    EditAction,
};
use Filament\Tables\Columns\TextColumn;

/**
 * Client resource class
 *
 * @package  App
 * @category Filament
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class ClientResource extends Resource
{
    protected static ?string $model = Client::class;

    protected static ?string $slug = 'client';

    protected static ?string $navigationIcon = 'heroicon-s-desktop-computer';

    protected static function getNavigationLabel(): string
    {
        return __('Client Manager');
    }

    public static function getModelLabel(): string
    {
        return __('Client');
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Components\Select::make('domain_id')->relationship('domain', 'name')
                ->required()->label(__('Domain')),
            Components\Select::make('transport_id')->relationship('transport', 'name')
                ->required()->label(__('Transport')),
            Components\TextInput::make('name')->required()->label(__('Name')),
            Components\TextInput::make('from_address')->email()->required()->label(__('From Address')),
            Components\Textarea::make('ip_addresses')->label(__('Ip Addresses')),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->sortable()->label(__('Name')),
            TextColumn::make('from_address')->label(__('From Address')),
            TextColumn::make('domain.name')->label(__('Domain')),
            TextColumn::make('transport.name')->label(__('Transport')),
            TextColumn::make('created_at')->dateTime()->sortable()->label(__('Created At')),
        ])->filters([
            //
        ])->actions([
            EditAction::make(),
            DeleteAction::make()->before(function (DeleteAction $action) {
                self::deleteByClients([$action->getRecord()->id]);
            }),
        ])->bulkActions([
            DeleteBulkAction::make()->before(function (DeleteBulkAction $action) {
                $clients = [0];
                foreach ($action->getRecords() as $record) {
                    $clients[] = (int) $record->id;
                }
                self::deleteByClients($clients);
            }),
        ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListClients::route('/'),
            'create' => Pages\CreateClient::route('/create'),
            'edit' => Pages\EditClient::route('/{record}/edit'),
        ];
    }

    public static function mutateFormData(array $data): array
    {
        $ip_addresses = explode(PHP_EOL, $data['ip_addresses']);
        $ips = [];
        foreach ($ip_addresses as $ip) {
            $ip = trim($ip);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                $ips[] = $ip;
            }
        }
        $data['ip_addresses'] = implode(PHP_EOL, $ips);

        return $data;
    }

    public static function afterSaveClient(Client $client)
    {
        self::deleteByClients([$client->id]);

        $ip_addresses = explode(PHP_EOL, $client->ip_addresses);
        foreach ($ip_addresses as $client_ip) {
            $clientAccess = ClientAccess::create([
                'client_id' => $client->id,
                'client_ip' => $client_ip,
                'access' => 'OK',
            ]);
            $clientAccess->save();
        }

        $senderAccess = SenderAccess::create([
            'client_id' => $client->id,
            'sender' => $client->from_address,
            'access' => 'OK',
        ]);
        $senderAccess->save();

        $senderTransport = SenderTransport::create([
            'client_id' => $client->id,
            'sender' => $client->from_address,
            'transport' => $client->transport->name,
        ]);
        $senderTransport->save();
    }

    private static function deleteByClients(array $client_ids)
    {
        ClientAccess::whereIn('client_id', $client_ids)->delete();
        SenderAccess::whereIn('client_id', $client_ids)->delete();
        SenderTransport::whereIn('client_id', $client_ids)->delete();
    }
}
