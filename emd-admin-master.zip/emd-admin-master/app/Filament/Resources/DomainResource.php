<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Filament\Resources\DomainResource\Pages;
use App\Models\{
    Client,
    Domain,
};
use Filament\Forms\Components\{
    Textarea,
    TextInput,
};
use Filament\Notifications\Notification;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Support\Actions\Action;
use Filament\Tables\Actions\{
    DeleteAction,
    DeleteBulkAction,
    EditAction,
};
use Filament\Tables\Columns\{
    TagsColumn,
    TextColumn,
};

/**
 * Domain resource class
 *
 * @package  App
 * @category Filament
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class DomainResource extends Resource
{
    protected static ?string $model = Domain::class;

    protected static ?string $slug = 'domain';

    protected static ?string $navigationIcon = 'heroicon-s-cog';

    protected static function getNavigationLabel(): string
    {
        return __('Domain Manager');
    }

    public static function getModelLabel(): string
    {
        return __('Domain');
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('name')->required()->label(__('Name')),
            TextInput::make('dkim_selector')->label(__('Dkim Selector')),
            Textarea::make('dkim_private_key')->label(__('Dkim Private Key')),
            Textarea::make('dkim_public_key')->label(__('Dkim Public Key')),
            TextInput::make('dkim_dns_record')->label(__('Dkim Dns Record')),
            TextInput::make('dmarc_dns_record')->label(__('Dmarc Dns Record')),
            TextInput::make('spf_dns_record')->label(__('Spf Dns Record')),
            TextInput::make('ptr_dns_record')->label(__('Ptr Dns Record')),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->sortable()->label(__('Name')),
            TagsColumn::make('clients.name')->limit(2)->label(__('Clients')),
            TextColumn::make('dkim_selector')->label(__('Dkim Selector')),
            TextColumn::make('created_at')->dateTime()->sortable()->label(__('Created At')),
        ])->filters([
            //
        ])->actions([
            EditAction::make(),
            DeleteAction::make()->before(function (DeleteAction $action) {
                if (self::countClient([$action->getRecord()->id]) > 0) {
                    self::cancelDelete($action);
                }
            }),
        ])->bulkActions([
            DeleteBulkAction::make()->before(function (DeleteBulkAction $action) {
                $domains = [0];
                foreach ($action->getRecords() as $record) {
                    $domains[] = (int) $record->id;
                }
                if (self::countClient($domains) > 0) {
                    self::cancelDelete($action);
                }
            }),
        ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDomains::route('/'),
            'create' => Pages\CreateDomain::route('/create'),
            'edit' => Pages\EditDomain::route('/{record}/edit'),
        ];
    }

    private static function countClient(array $domain_ids): int
    {
        return Client::whereIn('domain_id', $domain_ids)->count();
    }

    private static function cancelDelete(Action $action): void
    {
        Notification::make()
            ->warning()
            ->title(__('Unable to delete domain'))
            ->body(__('You must delete all clients belongs to the domain.'))
            ->send();
        $action->cancel();
    }
}
