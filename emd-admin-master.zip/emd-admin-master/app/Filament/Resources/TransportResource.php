<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Filament\Resources\TransportResource\Pages;
use App\Models\{
    Client,
    Transport,
};
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Resources\{
    Form,
    Resource,
    Table,
};
use Filament\Support\Actions\Action;
use Filament\Tables\Actions\{
    DeleteAction,
    DeleteBulkAction,
    EditAction,
};
use Filament\Tables\Columns\TextColumn;

/**
 * Transport resource class
 *
 * @package  App
 * @category Filament
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class TransportResource extends Resource
{
    protected static ?string $model = Transport::class;

    protected static ?string $slug = 'transport';

    protected static ?string $navigationIcon = 'heroicon-s-share';

    protected static function getNavigationLabel(): string
    {
        return __('Transport Manager');
    }

    public static function getModelLabel(): string
    {
        return __('Transport');
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('name')->required()->label(__('Name')),
            TextInput::make('ip_address')->required()->ipv4()->label(__('Ip Address')),
            TextInput::make('port')->integer()->required()->label(__('Port')),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->sortable()->label(__('Name')),
            TextColumn::make('ip_address')->label(__('Ip Address')),
            TextColumn::make('port')->label(__('Port')),
            TextColumn::make('created_at')->dateTime()->sortable()->label(__('Created At')),
        ])->filters([
            //
        ])->actions([
            EditAction::make(),
            DeleteAction::make()->before(function (DeleteAction $action) {
                if (self::countClient([$action->getRecord()->id]) > 0) {
                    self::cancelDelete($action);
                }
            }),
        ])->bulkActions([
            DeleteBulkAction::make()->before(function (DeleteBulkAction $action) {
                $transports = [0];
                foreach ($action->getRecords() as $record) {
                    $transports[] = (int) $record->id;
                }
                if (self::countClient($transports) > 0) {
                    self::cancelDelete($action);
                }
            }),
        ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTransports::route('/'),
            'create' => Pages\CreateTransport::route('/create'),
            'edit' => Pages\EditTransport::route('/{record}/edit'),
        ];
    }    

    private static function countClient(array $transport_ids): int
    {
        return Client::whereIn('transport_id', $transport_ids)->count();
    }

    private static function cancelDelete(Action $action): void
    {
        Notification::make()
            ->warning()
            ->title(__('Unable to delete transport'))
            ->body(__('You must delete all clients belongs to the transport.'))
            ->send();
        $action->cancel();
    }
}
