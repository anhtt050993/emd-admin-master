<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Trusted host model class
 *
 * @package  App
 * @category Model
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class TrustedHost extends Model
{
    use HasFactory;

    protected $table = 'restrict_addresses';

    protected $fillable = [
        'client_ip',
    ];
}
