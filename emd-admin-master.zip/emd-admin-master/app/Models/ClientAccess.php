<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Client access model class
 *
 * @package  App
 * @category Model
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class ClientAccess extends Model
{
    use HasFactory;

    protected $table = 'client_accesses';

    protected $fillable = [
        'client_id',
        'client_ip',
        'access',
    ];
}
