<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Sender transport model class
 *
 * @package  App
 * @category Model
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class SenderTransport extends Model
{
    use HasFactory;

    protected $table = 'sender_transports';

    protected $fillable = [
        'client_id',
        'sender',
        'transport',
    ];
}
